import 'package:recquest_21/core/app_export.dart';

class ApiClient extends GetConnect {}
