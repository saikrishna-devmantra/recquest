import 'package:recquest_21/core/app_export.dart';
import 'package:recquest_21/presentation/mainhome_container_screen/models/mainhome_container_model.dart';
import 'package:recquest_21/widgets/custom_bottom_bar.dart';

class MainhomeContainerController extends GetxController {
  Rx<MainhomeContainerModel> mainhomeContainerModelObj =
      MainhomeContainerModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  @override
  void onInit() {}
}
