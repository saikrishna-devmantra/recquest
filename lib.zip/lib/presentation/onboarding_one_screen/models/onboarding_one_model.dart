import 'package:get/get.dart';
import 'onboarding_one_item_model.dart';

class OnboardingOneModel {
  RxList<OnboardingOneItemModel> onboardingOneItemList =
      RxList.filled(2, OnboardingOneItemModel());
}
