import 'package:recquest_21/core/app_export.dart';
import 'package:recquest_21/presentation/event_details_images_screen/models/event_details_images_model.dart';
// import 'package:recquest_21/widgets/custom_bottom_bar.dart';

class EventDetailsImagesController extends GetxController {
  Rx<EventDetailsImagesModel> eventDetailsImagesModelObj =
      EventDetailsImagesModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
