class StaggeredrectangleItemModel {}
