class CreateEventsModel {}
