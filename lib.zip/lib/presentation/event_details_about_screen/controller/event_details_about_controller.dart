import 'package:recquest_21/core/app_export.dart';
import 'package:recquest_21/presentation/event_details_about_screen/models/event_details_about_model.dart';
// import 'package:recquest_21/widgets/custom_bottom_bar.dart';

class EventDetailsAboutController extends GetxController {
  Rx<EventDetailsAboutModel> eventDetailsAboutModelObj =
      EventDetailsAboutModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
