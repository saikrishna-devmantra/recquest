import 'package:get/get.dart';
import 'listcalendar_item_model.dart';

class EventDetailsAboutModel {
  RxList<ListcalendarItemModel> listcalendarItemList =
      RxList.filled(2, ListcalendarItemModel());
}
