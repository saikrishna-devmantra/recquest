class OrganizerProfileEventsModel {}
