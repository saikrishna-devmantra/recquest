class StaggeredrectangleOneItemModel {}
