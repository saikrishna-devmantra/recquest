import 'package:get/get.dart';
import 'staggeredrectangle_one_item_model.dart';

class OrganizerProfileImagesModel {
  RxList<StaggeredrectangleOneItemModel> staggeredrectangleOneItemList =
      RxList.filled(4, StaggeredrectangleOneItemModel());
}
