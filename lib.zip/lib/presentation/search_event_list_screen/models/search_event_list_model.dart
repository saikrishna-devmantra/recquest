class SearchEventListModel {}
