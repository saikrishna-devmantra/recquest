class PicturesItemModel {}
