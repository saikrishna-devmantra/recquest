import 'package:get/get.dart';
import 'mainhome_item_model.dart';

class MainhomeModel {
  RxList<MainhomeItemModel> mainhomeItemList =
      RxList.filled(3, MainhomeItemModel());
}
