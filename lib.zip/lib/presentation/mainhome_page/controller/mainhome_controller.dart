import 'package:recquest_21/core/app_export.dart';
import 'package:recquest_21/presentation/mainhome_page/models/mainhome_model.dart';

class MainhomeController extends GetxController {
  MainhomeController(this.mainhomeModelObj);

  Rx<MainhomeModel> mainhomeModelObj;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
