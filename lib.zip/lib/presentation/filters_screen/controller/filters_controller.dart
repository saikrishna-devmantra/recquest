import 'package:recquest_21/core/app_export.dart';
import 'package:recquest_21/presentation/filters_screen/models/filters_model.dart';

class FiltersController extends GetxController {
  Rx<FiltersModel> filtersModelObj = FiltersModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
