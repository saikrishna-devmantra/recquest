class PhotoOpenOverlayModel {}
