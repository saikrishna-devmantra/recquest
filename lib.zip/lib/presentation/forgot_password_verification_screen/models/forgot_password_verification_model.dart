class ForgotPasswordVerificationModel {}
