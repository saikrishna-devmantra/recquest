class ForgotPasswordModel {}
