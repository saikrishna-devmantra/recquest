class SearchEventsItemModel {}
