import 'package:get/get.dart';
import 'invite_friends_item_model.dart';

class InviteFriendsModel {
  RxList<InviteFriendsItemModel> inviteFriendsItemList =
      RxList.filled(10, InviteFriendsItemModel());
}
