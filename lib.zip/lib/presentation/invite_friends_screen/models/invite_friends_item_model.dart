class InviteFriendsItemModel {}
