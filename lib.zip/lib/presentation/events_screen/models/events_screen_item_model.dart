class EventsScreenItemModel {}
