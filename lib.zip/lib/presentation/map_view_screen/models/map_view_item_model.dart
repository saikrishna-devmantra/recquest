class MapViewItemModel {}
