class NotificationsEmptyModel {}
