import 'package:recquest_21/core/app_export.dart';
import 'package:recquest_21/presentation/notifications_empty_screen/models/notifications_empty_model.dart';

class NotificationsEmptyController extends GetxController {
  Rx<NotificationsEmptyModel> notificationsEmptyModelObj =
      NotificationsEmptyModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
