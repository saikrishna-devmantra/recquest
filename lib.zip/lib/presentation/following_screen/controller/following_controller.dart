import 'package:recquest_21/core/app_export.dart';
import 'package:recquest_21/presentation/following_screen/models/following_model.dart';

class FollowingController extends GetxController {
  Rx<FollowingModel> followingModelObj = FollowingModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
