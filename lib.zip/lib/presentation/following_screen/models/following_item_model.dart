class FollowingItemModel {}
