class ListellipsefiftytwoItemModel {}
