class ImageConstant {
  static String imgImage88 = 'assets/images/img_image88.png';

  static String imgVectorDeepOrangeA200 =
      'assets/images/img_vector_deep_orange_a200.svg';

  static String imgVectorGray9008x2 =
      'assets/images/img_vector_gray_900_8x2.svg';

  static String imgRectangle6 = 'assets/images/img_rectangle6.png';

  static String imgVectorGray700 = 'assets/images/img_vector_gray_700.svg';

  static String imgCar = 'assets/images/img_car.svg';

  static String imgGroupRed1001x1 = 'assets/images/img_group_red_100_1x1.svg';

  static String imgVectorPurple4001x1 =
      'assets/images/img_vector_purple_400_1x1.svg';

  static String imgVector7x8 = 'assets/images/img_vector_7x8.svg';

  static String imgFire19x19 = 'assets/images/img_fire_19x19.svg';

  static String imgRectangle419247x375 =
      'assets/images/img_rectangle4192_47x375.png';

  static String imgMusic1 = 'assets/images/img_music_1.svg';

  static String imgVectorRed200 = 'assets/images/img_vector_red_200.svg';

  static String imgLocation14x12 = 'assets/images/img_location_14x12.svg';

  static String imgImage8022x84 = 'assets/images/img_image80_22x84.png';

  static String imgVectorPurple2001x5 =
      'assets/images/img_vector_purple_200_1x5.svg';

  static String imgGroup90x69 = 'assets/images/img_group_90x69.svg';

  static String imgEllipse583 = 'assets/images/img_ellipse58_3.png';

  static String imgSearchPink80001 = 'assets/images/img_search_pink_800_01.svg';

  static String imgRectangle7 = 'assets/images/img_rectangle7.png';

  static String imgCalendar35x35 = 'assets/images/img_calendar_35x35.svg';

  static String imgVectorGray900014x7 =
      'assets/images/img_vector_gray_900_01_4x7.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgVector18x15 = 'assets/images/img_vector_18x15.svg';

  static String imgVector10 = 'assets/images/img_vector10.svg';

  static String imgOvalcopy5 = 'assets/images/img_ovalcopy5.png';

  static String imgRectangleGray20004 =
      'assets/images/img_rectangle_gray_200_04.svg';

  static String imgImage70 = 'assets/images/img_image70.png';

  static String imgVectorPurple2001x1 =
      'assets/images/img_vector_purple_200_1x1.svg';

  static String imgImage2 = 'assets/images/img_image2.png';

  static String imgGroup33596 = 'assets/images/img_group33596.svg';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgVectorGray9003x1 =
      'assets/images/img_vector_gray_900_3x1.svg';

  static String imgVector4x4 = 'assets/images/img_vector_4x4.svg';

  static String imgImage8492x79 = 'assets/images/img_image84_92x79.png';

  static String imgMenu51x51 = 'assets/images/img_menu_51x51.svg';

  static String imgReply54x48 = 'assets/images/img_reply_54x48.svg';

  static String imgMusic58x58 = 'assets/images/img_music_58x58.svg';

  static String imgFilter = 'assets/images/img_filter.svg';

  static String imgVectorRed2004x4 = 'assets/images/img_vector_red_200_4x4.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgMusic2 = 'assets/images/img_music_2.svg';

  static String imgMusic = 'assets/images/img_music.svg';

  static String imgGroupRed2004x7 = 'assets/images/img_group_red_200_4x7.svg';

  static String imgVectorBlueGray700 =
      'assets/images/img_vector_blue_gray_700.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgVectorDeepOrange300 =
      'assets/images/img_vector_deep_orange_300.svg';

  static String imgEllipse586 = 'assets/images/img_ellipse58_6.png';

  static String imgEllipse589 = 'assets/images/img_ellipse58_9.png';

  static String imgPhotoopenoverlay = 'assets/images/img_photoopenoverlay.png';

  static String imgVolume54x48 = 'assets/images/img_volume_54x48.svg';

  static String imgVectorDeepOrangeA2001x3 =
      'assets/images/img_vector_deep_orange_a200_1x3.svg';

  static String imgShare = 'assets/images/img_share.svg';

  static String imgVectorGray9001x3 =
      'assets/images/img_vector_gray_900_1x3.svg';

  static String imgImage86 = 'assets/images/img_image86.png';

  static String imgMusic24x11 = 'assets/images/img_music_24x11.svg';

  static String imgFacebook = 'assets/images/img_facebook.svg';

  static String imgVector10x13 = 'assets/images/img_vector_10x13.svg';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String imgVectorWhiteA700 = 'assets/images/img_vector_white_a700.svg';

  static String imgImage85 = 'assets/images/img_image85.png';

  static String imgArrowrightPink80001 =
      'assets/images/img_arrowright_pink_800_01.svg';

  static String imgReply = 'assets/images/img_reply.svg';

  static String imgCheckmark26x24 = 'assets/images/img_checkmark_26x24.svg';

  static String imgGroup33449 = 'assets/images/img_group33449.png';

  static String imgGroup760 = 'assets/images/img_group760.svg';

  static String imgLocation8x7 = 'assets/images/img_location_8x7.svg';

  static String imgClose32x32 = 'assets/images/img_close_32x32.svg';

  static String imgVolume1 = 'assets/images/img_volume_1.svg';

  static String imgOffer20x23 = 'assets/images/img_offer_20x23.svg';

  static String imgLocation1 = 'assets/images/img_location_1.svg';

  static String imgLightbulb27x21 = 'assets/images/img_lightbulb_27x21.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgEllipse = 'assets/images/img_ellipse.png';

  static String imgVolume40x40 = 'assets/images/img_volume_40x40.svg';

  static String imgGroup717 = 'assets/images/img_group717.svg';

  static String imgRectangle9 = 'assets/images/img_rectangle9.png';

  static String imgImage23 = 'assets/images/img_image23.png';

  static String imgFire13x13 = 'assets/images/img_fire_13x13.svg';

  static String imgImage8480x84 = 'assets/images/img_image84_80x84.png';

  static String imgVectorBlueGray9001x1 =
      'assets/images/img_vector_blue_gray_900_1x1.svg';

  static String imgArtwork = 'assets/images/img_artwork.svg';

  static String imgVector6x17 = 'assets/images/img_vector_6x17.svg';

  static String imgVector5 = 'assets/images/img_vector_5.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgGroupRed200 = 'assets/images/img_group_red_200.svg';

  static String imgVector1 = 'assets/images/img_vector_1.svg';

  static String imgOffer37x55 = 'assets/images/img_offer_37x55.svg';

  static String imgGlobe = 'assets/images/img_globe.svg';

  static String imgEllipse585 = 'assets/images/img_ellipse58_5.png';

  static String imgVector2 = 'assets/images/img_vector2.svg';

  static String imgVector2x2 = 'assets/images/img_vector_2x2.svg';

  static String imgLocation12x12 = 'assets/images/img_location_12x12.svg';

  static String imgVector19x14 = 'assets/images/img_vector_19x14.svg';

  static String imgVectorRedA200 = 'assets/images/img_vector_red_a200.svg';

  static String imgVector16x12 = 'assets/images/img_vector_16x12.svg';

  static String imgForward = 'assets/images/img_forward.svg';

  static String imgEllipse58 = 'assets/images/img_ellipse58.png';

  static String imgImage8680x84 = 'assets/images/img_image86_80x84.png';

  static String imgCheckmark37x36 = 'assets/images/img_checkmark_37x36.svg';

  static String imgVectorDeepOrange100 =
      'assets/images/img_vector_deep_orange_100.svg';

  static String imgEllipse52 = 'assets/images/img_ellipse52.png';

  static String imgVectorPurple100 = 'assets/images/img_vector_purple_100.svg';

  static String imgFavorite1 = 'assets/images/img_favorite_1.svg';

  static String imgRectangle12x8 = 'assets/images/img_rectangle_12x8.png';

  static String imgEllipse588 = 'assets/images/img_ellipse58_8.png';

  static String imgMap16x16 = 'assets/images/img_map_16x16.svg';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgVector3x1 = 'assets/images/img_vector_3x1.svg';

  static String imgImage771 = 'assets/images/img_image77_1.png';

  static String imgSend = 'assets/images/img_send.svg';

  static String imgEye14x17 = 'assets/images/img_eye_14x17.svg';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgRectangle9x5 = 'assets/images/img_rectangle_9x5.png';

  static String imgVector18x27 = 'assets/images/img_vector_18x27.svg';

  static String imgLogo = 'assets/images/img_logo.png';

  static String imgLightbulb74x47 = 'assets/images/img_lightbulb_74x47.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgVector74x51 = 'assets/images/img_vector_74x51.svg';

  static String imgBookmark = 'assets/images/img_bookmark.svg';

  static String imgVectorPurple2003x5 =
      'assets/images/img_vector_purple_200_3x5.svg';

  static String imgVolume2 = 'assets/images/img_volume_2.svg';

  static String imgFire = 'assets/images/img_fire.svg';

  static String imgOval = 'assets/images/img_oval.png';

  static String imgVector13x13 = 'assets/images/img_vector_13x13.svg';

  static String imgGroupCyan100 = 'assets/images/img_group_cyan_100.svg';

  static String imgCrop = 'assets/images/img_crop.svg';

  static String imgGlobe58x58 = 'assets/images/img_globe_58x58.svg';

  static String imgCar19x19 = 'assets/images/img_car_19x19.svg';

  static String imgIcon = 'assets/images/img_icon.svg';

  static String imgVector39x48 = 'assets/images/img_vector_39x48.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgOvalcopy = 'assets/images/img_ovalcopy.png';

  static String imgGroupRed100 = 'assets/images/img_group_red_100.svg';

  static String imgFavorite7x10 = 'assets/images/img_favorite_7x10.svg';

  static String imgVector51x35 = 'assets/images/img_vector_51x35.svg';

  static String imgBackground = 'assets/images/img_background.svg';

  static String imgVector4 = 'assets/images/img_vector_4.svg';

  static String imgVectorBlueGray7005x43 =
      'assets/images/img_vector_blue_gray_700_5x43.svg';

  static String imgEye26x24 = 'assets/images/img_eye_26x24.svg';

  static String imgCheckmark16x14 = 'assets/images/img_checkmark_16x14.svg';

  static String imgCar58x58 = 'assets/images/img_car_58x58.svg';

  static String imgImage8492x69 = 'assets/images/img_image84_92x69.png';

  static String imgFavorite8x12 = 'assets/images/img_favorite_8x12.svg';

  static String imgMap = 'assets/images/img_map.svg';

  static String imgGroupGray600167x167 =
      'assets/images/img_group_gray_600_167x167.svg';

  static String imgVectorPurple40001 =
      'assets/images/img_vector_purple_400_01.svg';

  static String imgVectorLime900 = 'assets/images/img_vector_lime_900.svg';

  static String imgVectorDeepPurpleA1003x9 =
      'assets/images/img_vector_deep_purple_a100_3x9.svg';

  static String imgEllipse5842x42 = 'assets/images/img_ellipse58_42x42.png';

  static String imgOffer6x7 = 'assets/images/img_offer_6x7.svg';

  static String imgVector2x1 = 'assets/images/img_vector_2x1.svg';

  static String imgEllipse581 = 'assets/images/img_ellipse58_1.png';

  static String imgVectorPurple200 = 'assets/images/img_vector_purple_200.svg';

  static String imgRectanglePink80001 =
      'assets/images/img_rectangle_pink_800_01.svg';

  static String imgVectorBlueGray7002x1 =
      'assets/images/img_vector_blue_gray_700_2x1.svg';

  static String imgVector11x11 = 'assets/images/img_vector_11x11.svg';

  static String imgGroupGray600170x170 =
      'assets/images/img_group_gray_600_170x170.svg';

  static String imgSave = 'assets/images/img_save.svg';

  static String imgCheckmark6x9 = 'assets/images/img_checkmark_6x9.svg';

  static String imgVectorDeepOrange200 =
      'assets/images/img_vector_deep_orange_200.svg';

  static String imgLocation36x36 = 'assets/images/img_location_36x36.svg';

  static String imgFloatingicon = 'assets/images/img_floatingicon.svg';

  static String imgVector42x41 = 'assets/images/img_vector_42x41.svg';

  static String imgVectorGray80001 = 'assets/images/img_vector_gray_800_01.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgImage77175x332 = 'assets/images/img_image77_175x332.png';

  static String imgContrast24x26 = 'assets/images/img_contrast_24x26.svg';

  static String imgImage77210x375 = 'assets/images/img_image77_210x375.png';

  static String imgLocation14x14 = 'assets/images/img_location_14x14.svg';

  static String imgVectorDeepOrange2004x4 =
      'assets/images/img_vector_deep_orange_200_4x4.svg';

  static String imgVectorGray900011x1 =
      'assets/images/img_vector_gray_900_01_1x1.svg';

  static String imgCheckmark51x49 = 'assets/images/img_checkmark_51x49.svg';

  static String imgVectorPurple2004x1 =
      'assets/images/img_vector_purple_200_4x1.svg';

  static String imgVectorBlueGray7003x1 =
      'assets/images/img_vector_blue_gray_700_3x1.svg';

  static String imgVector3x5 = 'assets/images/img_vector_3x5.svg';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgCalendar20x18 = 'assets/images/img_calendar_20x18.svg';

  static String imgImage3 = 'assets/images/img_image3.png';

  static String imgImage89 = 'assets/images/img_image89.png';

  static String imgRectangle13x11 = 'assets/images/img_rectangle_13x11.png';

  static String imgVectorDeepOrange400 =
      'assets/images/img_vector_deep_orange_400.svg';

  static String imgVectorRedA2005x6 =
      'assets/images/img_vector_red_a200_5x6.svg';

  static String imgCall = 'assets/images/img_call.svg';

  static String imgReply50x35 = 'assets/images/img_reply_50x35.svg';

  static String imgCrop15x11 = 'assets/images/img_crop_15x11.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgVectorGray900014x11 =
      'assets/images/img_vector_gray_900_01_4x11.svg';

  static String imgVectorGray9001x1 =
      'assets/images/img_vector_gray_900_1x1.svg';

  static String imgBookmark17x28 = 'assets/images/img_bookmark_17x28.svg';

  static String imgLightbulb19x19 = 'assets/images/img_lightbulb_19x19.svg';

  static String imgImage77 = 'assets/images/img_image77.png';

  static String imgHeader = 'assets/images/img_header.svg';

  static String imgLocation2 = 'assets/images/img_location_2.svg';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgTwitter = 'assets/images/img_twitter.svg';

  static String imgFavorite6x8 = 'assets/images/img_favorite_6x8.svg';

  static String imgVectorBlueGray900 =
      'assets/images/img_vector_blue_gray_900.svg';

  static String imgGroup758 = 'assets/images/img_group758.svg';

  static String imgRectangle5 = 'assets/images/img_rectangle5.png';

  static String imgEllipse582 = 'assets/images/img_ellipse58_2.png';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgRectangle8 = 'assets/images/img_rectangle8.png';

  static String imgVectorDeepPurple50 =
      'assets/images/img_vector_deep_purple_50.svg';

  static String imgUser19x19 = 'assets/images/img_user_19x19.svg';

  static String imgRectangle = 'assets/images/img_rectangle.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgGroup18531 = 'assets/images/img_group_18531.svg';

  static String imgEllipse584 = 'assets/images/img_ellipse58_4.png';

  static String imgVectorGray900 = 'assets/images/img_vector_gray_900.svg';

  static String imgVector1x1 = 'assets/images/img_vector_1x1.svg';

  static String imgEllipse587 = 'assets/images/img_ellipse58_7.png';

  static String imgOffer = 'assets/images/img_offer.svg';

  static String imgVector8x12 = 'assets/images/img_vector_8x12.svg';

  static String imgRectangle4192 = 'assets/images/img_rectangle4192.png';

  static String imgImage80 = 'assets/images/img_image80.png';

  static String imgGroupBlueGray900 =
      'assets/images/img_group_blue_gray_900.svg';

  static String imgVector70x61 = 'assets/images/img_vector_70x61.svg';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgMusic19x18 = 'assets/images/img_music_19x18.svg';

  static String imgCheckmark30x26 = 'assets/images/img_checkmark_30x26.svg';

  static String imgVectorPurple2005x2 =
      'assets/images/img_vector_purple_200_5x2.svg';

  static String imgVectorBlueGray80001 =
      'assets/images/img_vector_blue_gray_800_01.svg';

  static String imgVectorGray7002x3 =
      'assets/images/img_vector_gray_700_2x3.svg';

  static String imgGroupGray600 = 'assets/images/img_group_gray_600.svg';

  static String imgQuestion = 'assets/images/img_question.svg';

  static String imgLightbulb46x8 = 'assets/images/img_lightbulb_46x8.svg';

  static String imgVectorBlueGray800012x2 =
      'assets/images/img_vector_blue_gray_800_01_2x2.svg';

  static String imgMinimize16x10 = 'assets/images/img_minimize_16x10.svg';

  static String imgTrash = 'assets/images/img_trash.svg';

  static String imgImage87 = 'assets/images/img_image87.png';

  static String imgCalendar = 'assets/images/img_calendar.svg';

  static String imgComputer = 'assets/images/img_computer.svg';

  static String imgRecquestlowerrbubble300 =
      'assets/images/img_recquestlowerrbubble300.svg';

  static String imgLocation24x24 = 'assets/images/img_location_24x24.svg';

  static String imgImage84 = 'assets/images/img_image84.png';

  static String imgVector6 = 'assets/images/img_vector_6.svg';

  static String imgVector7 = 'assets/images/img_vector_7.svg';

  static String imgImage81 = 'assets/images/img_image81.png';

  static String imgImage235x35 = 'assets/images/img_image2_35x35.png';

  static String imgRectangle41921 = 'assets/images/img_rectangle4192_1.png';

  static String imgLightbulb15x10 = 'assets/images/img_lightbulb_15x10.svg';

  static String imgVolume18x27 = 'assets/images/img_volume_18x27.svg';

  static String imgMinimize = 'assets/images/img_minimize.svg';

  static String imgVector21x33 = 'assets/images/img_vector_21x33.svg';

  static String imgVectorPurple2004x4 =
      'assets/images/img_vector_purple_200_4x4.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgVectorWhiteA7003x6 =
      'assets/images/img_vector_white_a700_3x6.svg';

  static String imgVector7x25 = 'assets/images/img_vector_7x25.svg';

  static String imgVectorDeepPurpleA100 =
      'assets/images/img_vector_deep_purple_a100.svg';

  static String imgLocation16x14 = 'assets/images/img_location_16x14.svg';

  static String imgVector54x36 = 'assets/images/img_vector_54x36.svg';

  static String imgVectorPurple300 = 'assets/images/img_vector_purple_300.svg';

  static String imgVector3 = 'assets/images/img_vector_3.svg';

  static String imgEdit13x12 = 'assets/images/img_edit_13x12.svg';

  static String imgGroupIndigo300 = 'assets/images/img_group_indigo_300.svg';

  static String imgImage21 = 'assets/images/img_image2_1.png';

  static String imgVectorDeepPurple300 =
      'assets/images/img_vector_deep_purple_300.svg';

  static String imgVectorPurple2002x3 =
      'assets/images/img_vector_purple_200_2x3.svg';

  static String imgVectorGray90001 = 'assets/images/img_vector_gray_900_01.svg';

  static String imgVectorPurple400 = 'assets/images/img_vector_purple_400.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
